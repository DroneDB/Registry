
function parseHeader(header: string): string {



}